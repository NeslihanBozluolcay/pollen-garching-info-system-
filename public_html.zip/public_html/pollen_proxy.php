<?php
// v9 - working parser
set_time_limit(30);
error_reporting(0);
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$url = 'https://www.donnerwetter.de/pollenflug/garching/DE16830.html';

$ctx = stream_context_create(array(
    'http' => array(
        'method'  => 'GET',
        'timeout' => 10,
        'header'  => "User-Agent: Mozilla/5.0\r\nAccept: text/html\r\nCookie: __cmpcc=1; gdpr=1\r\n",
        'ignore_errors' => true,
    ),
    'ssl' => array(
        'verify_peer'      => false,
        'verify_peer_name' => false,
    ),
));

$html = @file_get_contents($url, false, $ctx);

if ($html === false) {
    echo json_encode(array('error' => 'fetch failed'));
    exit;
}

// Structure per entry (discovered from real HTML):
//   <img src="...pollg[bgk].gif" ...>
//   ... <b><font size="2">NAME</font></b> ...
//   ... <img src="...poll[0-4].gif" ... alt="LEVEL"> ...
//
// Strategy: split HTML by pollg[bgk].gif markers, parse each chunk.

$parts = preg_split('/(pollg[bgk]\.gif)/i', $html, -1, PREG_SPLIT_DELIM_CAPTURE);

$catNames  = array('b' => 'Baum', 'g' => 'Gras', 'k' => 'Kraut');
$lvlLabels = array('0' => 'Keine', '1' => 'Schwach', '2' => 'Maessig', '3' => 'Stark', '4' => 'Sehr stark');

$pollen = array();

for ($i = 1; $i < count($parts) - 1; $i += 2) {
    $catGif = $parts[$i];   // "pollgb.gif", "pollgg.gif", or "pollgk.gif"
    $chunk  = $parts[$i+1]; // HTML until the next pollg*.gif

    // Category
    preg_match('/pollg([bgk])\.gif/i', $catGif, $cm);
    if (!isset($cm[1])) continue;
    $cat = strtolower($cm[1]);

    // Pollen name: inside <b> and <font> tags
    // Pattern: <b><font size="2">NAME</font></b>  or  <b>NAME</b>
    if (!preg_match('/<b>[^<]*(?:<font[^>]*>)?([^<]+)/i', $chunk, $nm)) continue;
    $name = trim($nm[1]);
    if (strlen($name) < 2) continue;

    // Level: poll[0-4].gif
    if (!preg_match('/poll([0-4])\.gif/i', $chunk, $lm)) continue;
    $lvl = (int)$lm[1];

    $pollen[] = array(
        'category'      => $cat,
        'category_name' => isset($catNames[$cat]) ? $catNames[$cat] : '?',
        'name'          => $name,
        'level'         => $lvl,
        'level_label'   => isset($lvlLabels[$lvl]) ? $lvlLabels[$lvl] : '?',
    );
}

// Filter to only active pollen (level > 0)
$active = array();
foreach ($pollen as $p) {
    if ($p['level'] > 0) {
        $active[] = $p;
    }
}

echo json_encode(array('pollen' => $active, 'count' => count($active), 'total_parsed' => count($pollen)));
